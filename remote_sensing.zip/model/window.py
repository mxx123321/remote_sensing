from typing import Optional, Callable, List, Any

import numpy as np
import torch
import torchvision.ops
from einops import rearrange
from torch import nn
import torch.utils.checkpoint as checkpoint
import torch.nn.functional as F
from torch import nn, Tensor
from torch.nn.init import trunc_normal_
def window_partition_3d(x, window_size):
    """
    Args:
        x: (B, L, W, H)
        window_size (int): window size

    Returns:
        windows: (num_windows*B, window_size, W, H)
    """
    B, L, W, H = x.shape
    x = x.view(B*window_size, L // window_size, W, H)
    #windows = x.permute(0, 1, 2, 3).contiguous().view(-1, window_size, C)
    return x

def window_reverse_3d(windows, window_size):
    """
    Args:
        windows: (num_windows*B, L//window_size, W, C)
        window_size (int): Window size
        L (int): Sequence length

    Returns:
        x: (B, L, C)
    """
    B, L, W, H = windows.shape
    B = int(windows.shape[0] //window_size) # L / window_size should be   2   
    
    x = windows.view(B, L * window_size, W, H)
    x = x.permute(0, 1, 2, 3).contiguous().view(B, -1, W, H)
    return x